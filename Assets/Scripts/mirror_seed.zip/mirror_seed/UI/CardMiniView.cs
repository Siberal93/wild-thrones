using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class CardMiniView : MonoBehaviour
{
    CardInstance card;
    Action<CardInstance> onClick;

    public static CardMiniView Create(Transform parent, CardInstance card, Action<CardInstance> onClick)
    {
        var go = new GameObject($"Card_{card.def.id}", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(parent, false);

        var rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(150, 190);

        var bg = go.GetComponent<Image>();
        bg.color = new Color(0.12f, 0.15f, 0.20f, 1f);

        var btn = go.AddComponent<Button>();
        btn.onClick.AddListener(() => onClick?.Invoke(card));

        // title
        var title = CreateTMP(go.transform, "Title", 18, FontStyles.Bold);
        title.text = card.def.name;
        title.alignment = TextAlignmentOptions.TopLeft;
        title.rectTransform.offsetMin = new Vector2(10, 10);
        title.rectTransform.offsetMax = new Vector2(-10, -10);

        // cost badge
        var cost = CreateTMP(go.transform, "Cost", 22, FontStyles.Bold);
        cost.text = card.def.cost.ToString();
        cost.alignment = TextAlignmentOptions.TopRight;
        cost.rectTransform.offsetMin = new Vector2(10, 10);
        cost.rectTransform.offsetMax = new Vector2(-10, -10);

        // desc (mini)
        var desc = CreateTMP(go.transform, "Desc", 14, FontStyles.Normal);
        desc.text = card.def.desc;
        desc.alignment = TextAlignmentOptions.BottomLeft;
        desc.rectTransform.offsetMin = new Vector2(10, 10);
        desc.rectTransform.offsetMax = new Vector2(-10, -10);

        var v = go.AddComponent<CardMiniView>();
        v.card = card;
        v.onClick = onClick;
        return v;
    }

    static TMP_Text CreateTMP(Transform parent, string name, float size, FontStyles style)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var t = go.AddComponent<TextMeshProUGUI>();
        t.fontSize = size;
        t.fontStyle = style;
        t.color = Color.white;
        t.textWrappingMode = TextWrappingModes.Normal;
        var rt = t.rectTransform;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        return t;
    }
}
