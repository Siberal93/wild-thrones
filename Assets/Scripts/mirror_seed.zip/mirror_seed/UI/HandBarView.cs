using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;

public class HandBarView : MonoBehaviour
{
    HorizontalLayoutGroup layout;
    Action<CardInstance> onCardClicked;
    List<CardMiniView> views = new();

    public static HandBarView Create(Transform parent, Action<CardInstance> onCardClicked)
    {
        var go = new GameObject("HandBar", typeof(RectTransform));
        go.transform.SetParent(parent, false);

        var rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(0, 0);

        var le = go.AddComponent<LayoutElement>();
        le.flexibleWidth = 1f;

        var layout = go.AddComponent<HorizontalLayoutGroup>();
        layout.spacing = 14;
        layout.childAlignment = TextAnchor.MiddleLeft;
        layout.childControlWidth = false;
        layout.childControlHeight = false;

        var v = go.AddComponent<HandBarView>();
        v.layout = layout;
        v.onCardClicked = onCardClicked;
        return v;
    }

    public void SetFlexible()
    {
        var le = GetComponent<LayoutElement>();
        le.flexibleWidth = 1f;
    }

    public void SetHand(List<CardInstance> hand)
    {
        // ricrea “semplice” per ora
        foreach (var c in views) if (c != null) Destroy(c.gameObject);
        views.Clear();

        if (hand == null) return;

        foreach (var card in hand)
        {
            var mv = CardMiniView.Create(transform, card, onCardClicked);
            views.Add(mv);
        }
    }
}
